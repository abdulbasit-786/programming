import React, { Component } from 'react';

import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import entrance from "./src/screens/entrance.js";
import login from "./src/screens/login.js";
import createAccount from "./src/screens/createAccount.js";
import updateAccountDetails from "./src/screens/updateAccountDetails.js";
import userProfile from './src/screens/userProfile.js';
import postChit from './src/screens/postChit.js';
import chitsFeed from './src/screens/chitsFeed.js';
import logout from './src/actions/logout.js';
import uploadChitPhoto from './src/actions/uploadChitPhoto.js';
import viewChitPhoto from './src/actions/viewChitPhoto.js';
import getUserPhoto from './src/actions/getUserPhoto.js';
import displayChitPhoto from './src/actions/displayChitPhoto.js';
import displayUserPhoto from './src/actions/displayUserPhoto.js';
import capturePhoto from './src/actions/capturePhoto.js';
import captureChitPhoto from './src/actions/captureChitPhoto.js';
import updateUserPhoto from './src/actions/updateUserPhoto.js';
import followUser from './src/actions/followUser.js';
import unfollowUser from './src/actions/unfollowUser.js';
import enterIDToSeeUserFollowers from './src/actions/enterIDToSeeUserFollowers.js';
import showUserFollowers from './src/actions/showUserFollowers.js';
import selectUserToSeeAccountsFollowedBy from './src/actions/selectUserToSeeAccountsFollowedBy.js';
import getAccountsFollowedByUser from './src/actions/getAccountsFollowedByUser.js';
import specifyUserToSearchFor from './src/actions/specifyUserToSearchFor.js';
import searchSpecifiedUser from './src/actions/searchSpecifiedUser.js';
import specifySingleUserToView from './src/actions/specifySingleUserToView.js';
import viewSpecifiedSingleUser from './src/actions/viewSpecifiedSingleUser.js';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

export default function AppNavigator() {
    return (
        <NavigationContainer>
            <Stack.Navigator initialRouteName="Entrance">
                <Stack.Screen name="entrance" component={entrance} options={{title:'Entrance / Home Screen'}} />
				<Stack.Screen name="login" component={login} options={{title:'Login Screen'}} />
                <Stack.Screen name="createAccount" component={createAccount} options={{title:'Account Creation Form'}} />
				<Stack.Screen name="updateAccountDetails" component={updateAccountDetails} options={{title:'Update Account Details Screen'}} />
                <Stack.Screen name="userProfile" component={profileTabNavigator} options={{title:'User Profile Screen'}} />
				<Stack.Screen name="postChit" component={postChit} options={{title:'Post A Chit'}} />
				<Stack.Screen name="chitsFeed" component={chitsFeed} options={{title:'Chits Feed Screen'}} />
				<Stack.Screen name="logout" component={logout} options={{title:'Logout'}} />
				<Stack.Screen name="uploadChitPhoto" component={uploadChitPhoto} options={{title:'Upload Chit Photo'}} />
				<Stack.Screen name="viewChitPhoto" component={viewChitPhoto} options={{title:'View Chit Photo'}} />
				<Stack.Screen name="getUserPhoto" component={getUserPhoto} options={{title:'Get User Photo'}} />
				<Stack.Screen name="displayChitPhoto" component={displayChitPhoto} options={{title:'Display Chit Photo'}} />
				<Stack.Screen name="displayUserPhoto" component={displayUserPhoto} options={{title:'Display User Photo'}} />
				<Stack.Screen name="capturePhoto" component={capturePhoto} options={{title:'Capture Photo'}} />
				<Stack.Screen name="captureChitPhoto" component={captureChitPhoto} options={{title:'Capture Chit Photo'}} />
				<Stack.Screen name="updateUserPhoto" component={updateUserPhoto} options={{title:'Update User Photo'}} />
				<Stack.Screen name="followUser" component={followUser} options={{title:'Follow User'}} />
				<Stack.Screen name="unfollowUser" component={unfollowUser} options={{title:'Unfollow User'}} />
				<Stack.Screen name="enterIDToSeeUserFollowers" component={enterIDToSeeUserFollowers} options={{title:'See User Followers'}} />
				<Stack.Screen name="showUserFollowers" component={showUserFollowers} options={{title:'User Followers'}} />
				<Stack.Screen name="selectUserToSeeAccountsFollowedBy" component={selectUserToSeeAccountsFollowedBy} options={{title:'See Accounts Followed By User'}} />
				<Stack.Screen name="getAccountsFollowedByUser" component={getAccountsFollowedByUser} options={{title:'Accounts Followed By User'}} />
				<Stack.Screen name="specifyUserToSearchFor" component={specifyUserToSearchFor} options={{title:'Search User'}} />
				<Stack.Screen name="searchSpecifiedUser" component={searchSpecifiedUser} options={{title:'User Searched'}} />
				<Stack.Screen name="specifySingleUserToView" component={specifySingleUserToView} options={{title:'Search Single User'}} />
				<Stack.Screen name="viewSpecifiedSingleUser" component={viewSpecifiedSingleUser} options={{title:'Single User Searched'}} />			
            </Stack.Navigator>
        </NavigationContainer>
    );//return ends here
}//function AppNavigator() ends here

function profileTabNavigator() {
    return (
        <Tab.Navigator>
			<Tab.Screen name="USER PROFILE" component={userProfile} />
            <Tab.Screen name="CHITS FEED" component={chitsFeed} />
            <Tab.Screen name="POST CHIT" component={postChit} />
        </Tab.Navigator>
    );//return ends here
}//function profileTabNavigator() ends here
