import React, { Component } from 'react';

import { 
	Text, 
	View, 
	Alert, 
	Button, 
	TextInput, 
	StyleSheet, 
	ToastAndroid, 
	AsyncStorage,
	ActivityIndicator, 
} from 'react-native';

import Logo from '../loadLogos/secondLogo.js';

import {styles} from '../stylesheet/stylesheet1.js'

export default class uploadChitPhoto extends Component {
    constructor(props){
        super(props);
        this.state = {
            chit_id: -1
        }
    }//constructor ends here
	
    setChitID = (chitIDString) => {
        AsyncStorage.setItem('chitPhotoID', chitIDString)
    }//setChitID ends here

    chitPhotoID = () => {
        const chit_id = this.state.chit_id;
        this.setChitID(chit_id);
		const { navigate } = this.props.navigation;
        navigate("captureChitPhoto");
    }//chitPhotoID ends here

    render() {
		return(
		<View style={styles.mainContainer}>
			<Logo/>
			<Text style={styles.centerText}>JS Filename: uploadChitPhoto.js</Text>
			<Text style={styles.heading}>Upload Chit Photo</Text>
			<Text style={styles.mainText}>Using this page you can upload your Chit photo.</Text>
			<Text/>
			<TextInput 
				placeholder="Enter Chit ID Here" 
				onChangeText={(chit_id) => this.setState({chit_id: chit_id})}
				underlineColorAndroid="transparent"
				style={styles.textInputStyle}
			/>
			<Text/>
			<Button 
				title="Show Picture" 
				onPress = {this.chitPhotoID}
			/>
		</View>
      )//return ends here
    }//render() ends here
	
}//class 'uploadChitPhoto' ends here
