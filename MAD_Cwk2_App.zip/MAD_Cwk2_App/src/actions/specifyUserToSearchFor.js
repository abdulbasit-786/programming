import React, { Component } from 'react';

import { 
	Text, 
	View, 
	Button, 
	TextInput, 
	StyleSheet, 
	AsyncStorage,
	KeyboardAvoidingView,
} from 'react-native';

import Logo from '../loadLogos/secondLogo.js';

import {styles} from '../stylesheet/stylesheet1.js';

export default class specifyUserToSearchFor extends Component {
    constructor(props){
        super(props);
        this.state = {
            user_id: '',
            given_name: '',
            family_name: '',
            email: '',
            searchQuery: '',
        }
    }//constructor ends here
	
    setSearchQuery = (searchQuery) => {
		AsyncStorage.setItem('SearchQuery', searchQuery)
	}//setSearchQuery ends here

    searchUser = () => {
        const searchQuery = this.state.searchQuery;
        this.setSearchQuery(searchQuery);
        const { navigate } = this.props.navigation;
        navigate("searchSpecifiedUser") //go to specified page
    }//searchUser ends here

    render() {
		return(
			<KeyboardAvoidingView style={styles.mainContainer}>
				<Logo/>
				<Text style={styles.centerText}>JS Filename: specifyUserToSearchFor.js</Text>
				<Text/>
				<Text style={styles.heading}>User Search Page</Text>
				<Text/>
				<Text style={styles.mainText}>Enter details of user to search.</Text>
				<Text/>
				<TextInput 
					placeholder="Enter Query" 
					onChangeText={(searchQuery) => this.setState({searchQuery: searchQuery})} 
					underlineColorAndroid="transparent"
					style={styles.textInputStyle}
				/>
				<Text/>
				<Button 
					title="Search User"
					color="darkgreen"
					onPress = {this.searchUser}
				/>
			</KeyboardAvoidingView>
		)//return ends here
    }//render() ends here
	
}//class 'specifyUserToSearchFor' ends here
