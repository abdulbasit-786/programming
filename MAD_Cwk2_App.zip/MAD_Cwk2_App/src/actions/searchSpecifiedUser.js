import React, { Component } from 'react';
import { 
	Text, 
	View, 
	Alert,
	FlatList, 
	StyleSheet, 
	AsyncStorage, 
	ActivityIndicator, 
	KeyboardAvoidingView,
} from 'react-native';

import Logo from '../loadLogos/secondLogo.js';

import {styles} from '../stylesheet/stylesheet1.js';

export default class searchSpecifiedUser extends Component {
    constructor(props){
        super(props);
        this.state = {
            dataList: [],
            isLoading: true,
        }
    }//constructor ends here

    getSearchQuery = async () => {
        try {
			const searchQuery = await AsyncStorage.getItem('SearchQuery')
			if (searchQuery !== null) { return (searchQuery) }
        } catch (error) {
			console.log(error)
        }
    };//get_query ends here

    getSpecifiedUser = async () => {
        var searchQuery = await this.getSearchQuery();
        const serverURL = 'http://10.0.2.2:3333/api/v0.0.5/search_user?q='+searchQuery;
        console.log("Query in getSpecifiedUser:" + searchQuery)
        return await fetch(serverURL)
        .then((response) => response.json())
        .then((responseJSON) => {
            this.setState({
                isLoading: false, dataList: responseJSON,
            }); console.log(this.state.dataList);
        }) .catch((error) => {
			Alert.alert("ERROR: Failed to display Chit photo.")
            console.log(error);
        });
    }//getSpecifiedUser ends here

    componentDidMount = () => {
        this.getSpecifiedUser();
    }//componentDidMount ends here
    
    render(){
        if (this.state.isLoading) {
            return ( 
				<View>
					<ActivityIndicator/>
				</View> 
			)
        }
        return (
            <KeyboardAvoidingView style={styles.mainContainer}>
				<Logo/>
				<Text style={styles.centerText}>JS Filename: searchSpecifiedUser.js</Text>
				<Text/>
				<Text style={styles.heading}>User Searched</Text>
				<Text/>
				<Text style={styles.mainText}>Details of searched users are below.</Text>
				<Text/>
				<FlatList
					data = {this.state.dataList}
					renderItem = {({ item }) => (
						<View>
							<Text style={styles.centerText}>User ID: {item.user_id}</Text>
							<Text style={styles.centerText}>Given Name: {item.given_name}</Text>
							<Text style={styles.centerText}>Family Name: {item.family_name}</Text>
							<Text style={styles.centerText}>Email: {item.email}</Text>
						</View>
					)}//renderItem ends here
					keyExtractor={(item) => item.user_id}
				/>
			</KeyboardAvoidingView>
        );//return ends here
    }//render() ends here
	
}//class 'searchSpecifiedUser' ends here
