import React, { Component } from 'react';

import { 
	Text, 
	View, 
	Alert,
	Button, 
	FlatList, 
	StyleSheet, 
	AsyncStorage, 
	ActivityIndicator, 
	KeyboardAvoidingView,
} from 'react-native';

import Logo from '../loadLogos/secondLogo.js';

import {styles} from '../stylesheet/stylesheet1.js';

export default class viewSpecifiedSingleUser extends Component {
    constructor(props){
        super(props);
        this.state = {
            dataList: [],
			chitIds: [],
			chitContent: [],
            isLoading: true,
        }
    }//constructor ends here

    getID = async () => {
        try {
			const user_id = await AsyncStorage.getItem('SingleID')
			if (user_id !== null) {
				return (user_id)
			}
        } catch (error) {
			console.log(error)
        }
    };//getID ends here

    viewSpecifiedSingleUser = async () => {
        var id = await this.getID();
        const serverURL = 'http://10.0.2.2:3333/api/v0.0.5/user/'+id+'/';
        console.log("User ID in viewSpecifiedSingleUser:" + id)
        return await fetch(serverURL)
        .then((response) => response.json())
        .then((responseJSON) => {
            const result = Object.keys(responseJSON).map(key=>({[key]:responseJSON[key]}));
            this.setState({ isLoading: false, dataList: result, });
            console.log(this.state.dataList);
			const keys = Object.keys(this.state.dataList)
			const length = keys.length;
			console.log(length);
        }) 
		.catch((error) => { 
			Alert.alert("ERROR: Failed to view user.")
			console.log(error); 
		});
    }//viewSpecifiedSingleUser ends here

    componentDidMount = () => {
        this.viewSpecifiedSingleUser();
    }//componentDidMount ends here
       
    render(){
        if (this.state.isLoading) {
            return ( 
				<View>
					<ActivityIndicator/>
				</View> 
			)
        } 
		return(
            <KeyboardAvoidingView style={styles.mainContainer}>
				<Logo/>
				<Text style={styles.centerText}>JS Filename: viewSpecifiedSingleUser.js</Text>
				<Text/>
				<Text style={styles.heading}>Single User Searched</Text>
				<Text/>
				<Text style={styles.mainText}>Below are details single user searched.</Text>
				<FlatList
					data = {this.state.dataList}
					renderItem = {({ item }) => (
						<View>
							<Text style={styles.centerText}>{item.user_id}</Text>
							<Text style={styles.centerText}>{item.given_name}</Text>
							<Text style={styles.centerText}>{item.family_name}</Text>
							<Text style={styles.centerText}>{item.email}</Text>
							<Text style={styles.centerText}>{this.state.chitIds}</Text>
							<Text style={styles.centerText}>{this.state.chitContent}</Text>
						</View>
					)}//renderItem ends here
					keyExtractor={(item) => item.user_id}
				/>
			</KeyboardAvoidingView>
        );//return ends here
    }//render() ends here
	
}//class 'viewSpecifiedSingleUser' ends here
