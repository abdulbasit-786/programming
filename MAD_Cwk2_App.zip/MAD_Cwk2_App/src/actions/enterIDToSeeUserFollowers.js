import React, { Component } from 'react';

import { 
	Text, 
	Button, 
	TextInput, 
	StyleSheet, 
	AsyncStorage,
	KeyboardAvoidingView,
} from 'react-native';

import Logo from '../loadLogos/secondLogo.js';

import {styles} from '../stylesheet/stylesheet1.js'

export default class enterIDToSeeUserFollowers extends Component {
    constructor(props){
        super(props);
        this.state = {
            id: -1,
        }
    }//constructor ends here
	
    setID = async (id) => { 
		AsyncStorage.setItem('FollowerID', id) 
	}

    getID = () => {
        const { navigate } = this.props.navigation;
        const id = this.state.id;
        this.setID(id);
        navigate("showUserFollowers")
    }//getID ends here
	
    render() {
		return(
			 <KeyboardAvoidingView style={styles.mainContainer}>
				<Logo/>
				<Text style={styles.centerText}>JS Filename: enterIDToSeeUserFollowers.js</Text>
				<Text/>
				<Text style={styles.heading}>See Followers of a User</Text>
				<Text/>
				<Text style={styles.mainText}>Please enter a user ID below to view its followers.</Text>
				<Text/>
				<TextInput 
					placeholder="Enter User ID Here" 
					onChangeText={(id) => this.setState({id: id})} 
					underlineColorAndroid="transparent"
					style={styles.textInputStyle}
				/>
				<Text/>
				<Button 
					title="View User Follower(s)" 
					color="darkgreen"
					onPress = {this.getID}
				/>
			</KeyboardAvoidingView>
		)//return ends here
    }//render() ends here
	
}//class 'enterIDToSeeUserFollowers' ends here
