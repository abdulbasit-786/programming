import React, { Component } from 'react';

import { 
	Text, 
	View, 
	Button, 
	TextInput, 
	StyleSheet, 
	AsyncStorage, 
	KeyboardAvoidingView,
} from 'react-native';

import Logo from '../loadLogos/secondLogo.js';

import {styles} from '../stylesheet/stylesheet1.js';

export default class specifySingleUserToView extends Component {
    constructor(props){
        super(props);
        this.state = {
            user_id: -1
        }
    }//constructor ends here

    setID = (id) => {AsyncStorage.setItem('SingleID', id)}

    getID = () => {
        const id = this.state.user_id;
        this.setID(id);
        const { navigate } = this.props.navigation;
        navigate("viewSpecifiedSingleUser")   
    }//getID ends here
	
	render() {
		return(
			<KeyboardAvoidingView style={styles.mainContainer}>
				<Logo/>
				<Text style={styles.centerText}>JS Filename: specifySingleUserToView.js</Text>
				<Text/>
				<Text style={styles.heading}>View Single User</Text>
				<Text/>
				<Text style={styles.mainText}>Specify below a single user to view.</Text>
				<TextInput 
					placeholder="Enter User ID Here" 
					onChangeText={(user_id) => {this.setState({user_id: user_id})}} 
					underlineColorAndroid="transparent"
					style={styles.textInputStyle}
				/>
				<Text/>
				<Button 
					title="View Specified User" 
					color="darkgreen"
					onPress = {this.getID}
				/>
			</KeyboardAvoidingView>
		)//return ends here
    }//render() ends here
	
}//class 'specifySingleUserToView' ends here
