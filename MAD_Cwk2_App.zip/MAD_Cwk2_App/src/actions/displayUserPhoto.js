import React, { Component } from 'react';

import { 
	Text, 
	View, 
	Image,
	Alert,
	StyleSheet, 
	AsyncStorage, 
	ActivityIndicator, 
} from 'react-native';

import Logo from '../loadLogos/secondLogo.js';

import {styles} from '../stylesheet/stylesheet1.js';

export default class displayUserPhoto extends Component {
    constructor(props){
        super(props);
        this.state = {
            isLoading: true,
			uri:'',
        }
    }//constructor ends here

    getID = async () => {
        try {
			const uri = await AsyncStorage.getItem('UserPhotoID')
			console.log("imgLocation for User Photo: " + uri)
			if (uri !== null) {
				this.state.uri = uri;
				this.setState({isLoading: false})
			}
        } catch (error) {
			Alert.alert("ERROR: Failed to display photo.")
			console.log("ERROR: Failed to display photo."+error)
        }
    };//getID ends here

    componentDidMount = () => {
        this.getID();
    }//componentDidMount ends here
       
    render(){
        if (this.state.isLoading) {
            return ( <View><ActivityIndicator/></View> )
        }//IF statement ends here
        return(
            <View>
				<Logo/>
				<Text style={styles.centerText}>JS Filename: displayUserPhoto.js</Text>
				<Text/>
				<Text style={styles.mainText}>User Profile Picture: </Text>
				<Text/>
                <Image 
					source = {{uri: this.state.uri}}
					style = {styles.imageStyle} 
				/>
            </View>
        );//return ends here
    }//render() ends here
	
}//class 'displayUserPhoto' ends here
