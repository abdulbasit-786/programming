import React, { Component } from 'react';
import {  
	View, 
	Alert, 
	Button, 
	StyleSheet, 
	AsyncStorage, 
} from 'react-native';

import {styles} from '../stylesheet/stylesheet1.js'

import {RNCamera} from 'react-native-camera';

export default class captureChitPhoto extends Component {
    constructor(props) {
        super(props);
        this.state = {
            chit_id:-1,
            token:'',
        }
    }//constructor ends here
    
	getChitID = async() => {
        const chit_id = AsyncStorage.getItem("chitPhotoID");
        this.state.chit_id = chit_id;
        const chitIDString = this.state.chit_id;
        const showChitID = chitIDString.toString();
        console.log("Chit_ID Obtained: " + showChitID)
        return(chit_id)
    }//getChidID ends here
	
    getToken = async() => {
        const token = await AsyncStorage.getItem("Token");
        this.state.token = token;
        console.log("Token Obtained: " + token)
    }//getToken ends here

    componentDidMount = async () => {
        await this.getToken();
    }//componentDidMount ends here
	
	capturePhoto = async () => {
        if (this.camera) {
            const options = { quality: 0.5, base64: true };
            const Obj = await this.camera.takePictureAsync(options);
            const token = this.state.token
            const tokenString = token.toString();
            const chit_id = await this.getChitID();
            const chitIDString = chit_id.toString();
            console.log(Obj.uri, this.state.token);
			const serverURL = 'http://10.0.2.2:3333/api/v0.0.5/chits/'+chitIDString+'/photo/';
            
			return fetch(serverURL, {
                method: 'POST', headers: {
                    'Content-Type': 'image/jpeg',
                    'X-Authorization': tokenString
                }, body: Obj
            }) 
			.then((response) => {
				Alert.alert("SUCCESS: Photo Added!");
			}) 
			.catch((error) => {
				Alert.alert("ERROR: Failed to capture Chit photo.")
				console.log(error)
			});
        }//IF statement ends here
    };//capturePhoto ends here

    render() {
        return (
			<View style={styles.camContainer}>
                <RNCamera
					ref={ref => { this.camera = ref; }}
                    style={styles.photoPreview}
                />
                <View style={styles.camContainer2}>
                    <Button
						title="Capture Chit Photo"
						color="darkgreen"
						onPress={this.capturePhoto.bind(this)}
					/>
                </View>
            </View>
        );//return ends here
    }//render() ends here
	
}//class 'captureChitPhoto' ends here
