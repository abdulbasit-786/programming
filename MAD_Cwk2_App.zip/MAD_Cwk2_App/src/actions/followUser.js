import React, { Component } from 'react';

import { 
	Text, 
	View, 
	Button, 
	TextInput, 
	StyleSheet, 
	ToastAndroid, 
	AsyncStorage, 
	KeyboardAvoidingView, 
} from 'react-native';

import {createStackNavigator} from '@react-navigation/stack';
import { NavigationActions, withNavigation } from 'react-navigation';
import {CommonActions, NavigationContainer, StackActions} from '@react-navigation/native';

import Logo from '../loadLogos/secondLogo.js';

import {styles} from '../stylesheet/stylesheet1.js'

export default class followUser extends Component {
	constructor(props) {
		super(props);
		this.state = {
			id: -1,
			token: '',
		};
	}//constructor ends here
  
	getToken = async () => {
		try {
			const token = await AsyncStorage.getItem('Token');
			if (token !== null) {
				return(token)
				console.log("followUser Token: " + token)
			}
		} catch (error) {
		  console.log(error)
		}
	};//getToken ends ere

	waitingTimer = async () => {
		var token = await this.getToken();
		this.setState({token: token})
		this.followUser();
	}//waitingTimer ends here

	followUser = () => {
		const id = this.state.id
		const displayToken = this.state.token
		const { navigate } = this.props.navigation;
		serverURL = 'http://10.0.2.2:3333/api/v0.0.5/user/'+id+'/follow'
		fetch(serverURL, {
		  method: 'POST', headers: {
			Accept: 'application/json',
			'Content-Type': 'application/json',
			'X-Authorization': "" + displayToken
		  },
		}) .then((response) => {
		  ToastAndroid.show("SUCCESS: You are now following this user.", ToastAndroid.SHORT)
		});
	}//followUser ends here

    render() {
        return(
        <KeyboardAvoidingView>
            <Logo/>
			<Text style={styles.centerText}>JS Filename: followUser.js</Text>
			<Text/>
			<Text style={styles.mainHeading}>Follow User Page</Text>
			<Text/>
			<Text style={styles.mainText}>Use this page to follow the user of your choice.</Text>
            <Text/>
			<TextInput 
				placeholder="Enter ID of User You Want To Follow" 
				onChangeText={(id) => this.setState({id: parseInt(id)})} 
				underlineColorAndroid="transparent"
				style={styles.textInputStyle}
			/>
            <Button 
				title="Follow User" 
				color="darkgreen"
				onPress={this.waitingTimer}
			/>
        </KeyboardAvoidingView>
        )//return ends here
    }//render() ends here
	
}//class 'followUser' ends here
