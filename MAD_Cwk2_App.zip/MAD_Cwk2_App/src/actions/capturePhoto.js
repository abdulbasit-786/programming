import React, { Component } from 'react';
import { 
	Text, 
	View, 
	Alert, 
	Button, 
	StyleSheet, 
	ToastAndroid,
	AsyncStorage, 
} from 'react-native';

import {styles} from '../stylesheet/stylesheet1.js'

import {RNCamera} from 'react-native-camera';

export default class capturePhoto extends Component {
    constructor(props) {
        super(props);
        this.state = {
            token: '',
        }
    }//constructor ends here
    
    getToken = async() => {
        const token = await AsyncStorage.getItem("Token");
        this.state.token = token;
        console.log("Token Obtained: " + token)
    }//getToken ends hee

    componentDidMount = async () => {
        await this.getToken();
    }//componentDidMount ends here

	capturePhoto = async () => {
        if(this.camera){
            const token = this.state.token
            const tokenToString = token.toString();
            const settings = { quality: 0.5, base64: true };
            const myObj = await this.camera.takePictureAsync(settings);
            console.log(myObj.uri, this.state.token)
			
			const serverURL = "http://10.0.2.2:3333/api/v0.0.5/user/photo/"
			
            return fetch(serverURL, {
                method: 'POST', headers: {
                    'Content-Type': 'image/jpeg',
                    'X-Authorization': tokenToString
                }, body: myObj
            }) .then((response) => {
				Alert.alert("SUCCESS: Photo Captured.")
            }) .catch((error) => {
				Alert.alert("ERROR: Failed to capture photo.")
				console.log(error)
			});
        }//IF statement ends here
    };//capturePhoto ends here
	
    render() {
        return (
            <View style={styles.camContainer}>
                <RNCamera
					ref={ref => {this.camera=ref;}}
					style={styles.photoPreview}
                />
                <View style={styles.camContainer2}>
                    <Button
                        title="Capture Photo"
						color="darkgreen"
                        onPress={this.capturePhoto.bind(this)}
                        style={styles.photoCaptureSettings}
                    />
                </View>
            </View>
        );//return ends here
    }//render() ends here
	
}//class 'capturePhoto' ends here
