import React, { Component } from 'react';

import { 
	Text, 
	View,  
	Button, 
	AsyncStorage,  
} from 'react-native';

import Logo from '../loadLogos/secondLogo.js';

import {styles} from '../stylesheet/stylesheet1.js'

export default class updateUserPhoto extends Component {
    constructor(props) {
        super(props);
        this.state = {
            id: -1,
            isLoading: true,
        }
    }//constructor ends here

    setID = (id) => {
		const idInt = parseInt(id);
        const timestamp = Date.now();
        const timestampToString = timestamp.toString()
        const serverURL = 'http://10.0.2.2:3333/api/v0.0.5/user/'+idInt+'/photo?'+timestampToString
        AsyncStorage.setItem('UserPhotoID', serverURL)
    }//storeID ends here

    takePhoto = async () => {
        const id = await AsyncStorage.getItem("id")
        this.setState({id: id});
        this.setID(id);
        const { navigate } = this.props.navigation;
        navigate("capturePhoto") //takes user to specified page
    }//takePhoto ends here

    render() {
        return (
            <View style={styles.mainContainer}>
				<Logo/>
				<Text style={styles.centerText}>JS Filename: updateUserPhoto.js</Text>
				<Text/>
				<Text style={styles.mainText}>Please click on the button below to start camera to take a picture for the user profile.</Text>
				<Text/>
                <Button 
					title="Camera"
					color="darkgreen"
					onPress={this.takePhoto}
				/>
            </View>
        )//return ends here
    }//render() ends here
	
}//class 'updateUserPhoto' ends here
