import React, { Component } from 'react';

import { 
	Text, 
	View, 
	Alert, 
	Button, 
	TextInput, 
	StyleSheet, 
	ToastAndroid, 
	AsyncStorage,
	ActivityIndicator, 
} from 'react-native';

import { NavigationContainer } from '@react-navigation/native';
import { createDrawerNavigator } from '@react-navigation/drawer';

import Logo from '../loadLogos/secondLogo.js';

import {styles} from '../stylesheet/stylesheet1.js'

export default class logout extends Component {
	constructor(props) {
		super(props);
		this.state = {
			token:'',
		}
	}//constructor ends here

	setToken = (token) => {
		this.state.token = token;
	}//setToken ends here
	
	getToken = async () => {
		try {
			const token = await AsyncStorage.getItem('Token');
			if(token !== null) {
				console.log("Logout Token Obtained: " + token);
				return(token)
			}
		} catch (error) {
			console.log(error)
		}
	};//getToken ends here

	componentDidMount = async () => {
		var token = await this.getToken();
		this.setState({token: token})
		this.logUserOut()
	}//waitingTimer ends here

	logUserOut = () => {
		const token = this.state.token
		const { navigate } = this.props.navigation;
		fetch("http://10.0.2.2:3333/api/v0.0.5/logout", {
			method: 'POST', headers: {
				'Content-Type': 'application/json',
				'X-Authorization': "" + token
			}
		}) .then((data) => {
			navigate("entrance")
		});
	}//logUserOur ends here
	
    render() {
        return(
			<View style={styles.mainContainer}>
				<Logo/>
				<Text style={styles.centerText}>JS Filename: logout.js</Text>
                <Text style={styles.heading}>User Account Logout</Text>
				<Text/>
				<Text style={styles.mainText}>Account logging out!</Text>
			</View>
        )//return ends here
    }//render() ends here
	
}//class 'logout' ends here
