import React, { Component } from 'react';

import { 
	Text, 
	View, 
	StyleSheet, 
	Button, 
	TextInput, 
	Alert, 
	ToastAndroid, 
	ActivityIndicator, 
	AsyncStorage, 
	FlatList, 
	TouchableWithoutFeedbackBase
} from 'react-native';

import Logo from '../loadLogos/secondLogo.js';

import {styles} from '../stylesheet/stylesheet1.js'

export default class viewChitPhoto extends Component {
    constructor(props){
        super(props);
        this.state = {
            id: -1,
            isLoading: true,
        }
    }//constructor ends here

    store_id = (id) => {
        const timestamp = Date.now();
        const timestampToString = timestamp.toString();
        const serverURL = 'http://10.0.2.2:3333/api/v0.0.5/chits/'+id+'/photo?'+timestampToString
        AsyncStorage.setItem('ChitPhotoID', serverURL)
    }//store_id ends here

    get_id = () => {
        const id = this.state.id;
        this.store_id(id);
        const { navigate } = this.props.navigation;
		navigate("displayChitPhoto")
    }//get_id ends here

    render() {
        return(
			<View style={styles.mainContainer}>
				<Logo/>
				<Text style={styles.centerText}>JS Filename: viewChitPhoto.js</Text>
                <Text style={styles.heading}>View Chit Photo</Text>
				<Text style={styles.mainText}>Enter Chit ID below and use the button to see the Chit picture.</Text>
				<Text/>
				<TextInput 
					placeholder="Enter Chit ID Here" 
					onChangeText={(id) => this.setState({id: id})} 
					underlineColorAndroid="transparent"
					style={styles.textInputStyle}
				/>
				<Text/>
				<Button 
					title="Show Picture" 
					color="darkgreen"
					onPress = {this.get_id}
				/>
			</View>
        )//return ends here
    }//render() ends here
	
}//class 'viewChitPhoto' ends here
