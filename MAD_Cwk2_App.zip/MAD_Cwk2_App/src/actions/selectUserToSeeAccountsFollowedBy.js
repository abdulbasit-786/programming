import React, { Component } from 'react';

import { 
	Text, 
	Button, 
	TextInput, 
	StyleSheet,
	AsyncStorage,
	KeyboardAvoidingView,
} from 'react-native';

import Logo from '../loadLogos/secondLogo.js';

import {styles} from '../stylesheet/stylesheet1.js';

export default class selectUserToSeeAccountsFollowedBy extends Component {
    constructor(props){
        super(props);
        this.state = {
            id: -1,
            data: '',
        }
    }//constructor ends here
	
    setID = async (id) => { AsyncStorage.setItem('FollowingID', id) }

    getAccountsFollowedByUser = () => {
        const id = this.state.id;
        this.setID(id);
        const { navigate } = this.props.navigation;
        navigate("getAccountsFollowedByUser")
    }//getID ends here
	
    render() {
		return(
			<KeyboardAvoidingView style={styles.mainContainer}>
				<Logo/>
				<Text style={styles.centerText}>JS Filename: selectUserToSeeAccountsFollowedBy.js</Text>
				<Text/>
				<Text style={styles.heading}>Search Accounts Followed By User</Text>
				<Text/>
				<Text style={styles.mainText}>Please enter ID of user to see what accounts it is following.</Text>
				<Text/>
				<TextInput 
					placeholder="Enter User ID Here" 
					onChangeText={(id) => this.setState({id: id})} 
					underlineColorAndroid="transparent"
					style={styles.textInputStyle}
				/>
				<Text/>
				<Button 
					title="View Accounts Followed By User" 
					color="darkgreen"
					onPress = {this.getAccountsFollowedByUser}
				/>
			</KeyboardAvoidingView>
		)//return ends here
    }//render() ends here
	
}//class 'selectUserToSeeAccountsFollowedBy' ends here
