import React, { Component } from 'react';

import { 
	Text, 
	View, 
	Alert, 
	Button, 
	TextInput, 
	StyleSheet, 
	AsyncStorage, 
	ToastAndroid, 
	KeyboardAvoidingView
} from 'react-native';

import {createStackNavigator} from '@react-navigation/stack';
import { NavigationActions, withNavigation } from 'react-navigation';
import {CommonActions, NavigationContainer, StackActions} from '@react-navigation/native';

import Logo from '../loadLogos/secondLogo.js';

import {styles} from '../stylesheet/stylesheet1.js'

export default class unfollowUser extends Component {
    constructor(props) {
		super(props);
		this.state = {
			user_id: -1,
			token: '',
		};
    }//constructor ends here
    
    getToken = async () => {
		try {
			const token = await AsyncStorage.getItem('Token');
			if (token !== null) {
			  console.log("unfollowUser Token: " + token)
			  return (token)
			}
		} catch (error) {
			console.log(error)
		}
    };//getToken ends here
  
    componentDidMount = async () => {
		var token = await this.getToken();
		this.setState({token: token})
		this.unfollowUser();
    }//componentDidMount ends here
  
    unfollowUser = () => {
		const userID = this.state.user_id
		const token = this.state.token
		const { navigate } = this.props.navigation;
		const serverURL = 'http://10.0.2.2:3333/api/v0.0.5/user/'+userID+'/follow/'
		fetch(serverURL, {
			method: 'DELETE', headers: {
				Accept: 'application/json',
				'Content-Type': 'application/json',
				'X-Authorization': "" + token
        },
		}) .then((response) => {
			ToastAndroid.show("User Successfully Unfollowed.", ToastAndroid.SHORT)
		});
    }//unfollowUser ends here
  
    render() {
        return(
			<KeyboardAvoidingView style={styles.mainContainer}>
				<Logo/>
				<Text style={styles.centerText}>JS Filename: unfollowUser.js</Text>
				<Text style={styles.heading}>Unfollow User Page</Text>
				<Text/>
				<Text style={styles.mainText}>Use this page to unfollow a user.</Text>
				<Text/>
				<TextInput 
					placeholder="Enter ID of User to Unfollow" 
					onChangeText={(user_id) => this.setState({user_id: parseInt(user_id)})} 
					underlineColorAndroid="transparent"
					style={styles.textInputStyle}
				/>
				<Button 
					title="Unfollow User" 
					color="darkgreen"
					onPress={this.unfollowUser}
				/>
			</KeyboardAvoidingView>
		)//return ends here
	}//render() ends here
	
}//class 'unfollowUser' ends here
