import React, { Component } from 'react';

import { 
	Text, 
	View, 
	Button, 
	FlatList, 
	StyleSheet, 
	AsyncStorage, 
	ActivityIndicator, 
	KeyboardAvoidingView
} from 'react-native';

import Logo from '../loadLogos/secondLogo.js';

import {styles} from '../stylesheet/stylesheet1.js'

export default class showUserFollowers extends Component {
    constructor(props){
        super(props);
        this.state = {
            dataList: [],
            isLoading: true,
        }
    }//constructor ends here

    getID = async () => {
        try {
			const id = await AsyncStorage.getItem('FollowerID')
			if (id !== null) {
				return (id)
			}
        } catch (error) {
          console.log(error)
        }
    };//getID ends here

    showUserFollowers = async () => {
		var id = await this.getID();
        const serverURL = 'http://10.0.2.2:3333/api/v0.0.5/user/'+id+'/followers/';
        console.log("Query in showUserFollowers:" + id)
        return await fetch(serverURL)
        .then((response) => response.json())
        .then((responseJSON) => {
            this.setState({
                isLoading: false, dataList: responseJSON,
            }); console.log(this.state.dataList);
        }) .catch((error) => {
            console.log(error);
        });
    }//showUserFollowers ends here

    componentDidMount = () => {
        this.showUserFollowers();
    }//componentDidMount ends here
    
    render(){
        if (this.state.isLoading) {
            return (<View><ActivityIndicator></ActivityIndicator></View>)
        } 
		return(
            <KeyboardAvoidingView style={styles.mainContainer}>
				<Logo/>
				<Text style={styles.centerText}>JS Filename: showUserFollowers.js</Text>
				<Text style={styles.heading}>User Followers Page</Text>
				<Text/>
				<Text style={styles.mainText}>Followers of the selected user are listed below.</Text>
				<FlatList
					data = {this.state.dataList}
					renderItem = {({ item }) => (
						<View style={styles.mainContainer}>
							<Text style={styles.centerText}>ID: {item.user_id}</Text>
							<Text style={styles.centerText}>Given Name: {item.given_name}</Text>
							<Text style={styles.centerText}>Last Name: {item.family_name}</Text>
							<Text style={styles.centerText}>Email: {item.email}</Text>
							<Text style={styles.centerText}>===========</Text>
						</View>
					)}//renderItem ends here
					keyExtractor={(item) => item.user_id}
				/>
			</KeyboardAvoidingView>
        );//return ends here
    }//render() ends here
	
}//class 'showUserFollowers' ends here
