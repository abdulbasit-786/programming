import React, { Component } from 'react';

import { 
	View, 
	Text,
	Image, 
	Alert,
	StyleSheet, 
	AsyncStorage, 
	ActivityIndicator, 
} from 'react-native';

import Logo from '../loadLogos/secondLogo.js';

import {styles} from '../stylesheet/stylesheet1.js'

export default class displayChitPhoto extends Component {
    constructor(props){
        super(props);
        this.state = {
            isLoading: true,
            imgLocation: '',
        }
    }//constructor ends here

    getID = async () => {
        try {
			const imgLocation = await AsyncStorage.getItem('ChitPhotoID')
			console.log("User imgLocation:: " + imgLocation)
			if (imgLocation !== null) {
				this.state.imgLocation = imgLocation;
				this.setState({isLoading: false})
			}
        } catch (error) {
			Alert.alert("ERROR: Failed to display Chit photo.")
			console.log("ERROR: Failed to display Chit photo."+error)
        }
    };//getID ends here

    componentDidMount = () => {
        this.getID();
    }//componentDidMount ends here
       
    render(){
        if (this.state.isLoading) {
            return (
                <View><ActivityIndicator/></View>
            )
        }//IF statement ends here
        return(
            <View style={styles.mainContainer}>
				<Logo/>
				<Text style={styles.centerText}>JS Filename: displayChitPhoto.js</Text>
				
				<Text style={styles.heading}>Chit Photo</Text>
				<Text/>
				<Text style={styles.mainText}>You can see the photo of the specified Chit below.</Text>
                <Text/>
				<Image 
					source = {{uri: this.state.imgLocation}} 
					style={styles.imageStyle} 
				/>
            </View>
        );//return ends here
    }//render() ends here
	
}//class 'displayChitPhoto' ends here
