import React, { Component } from 'react';

import { 
	Text, 
	View, 
	Button, 
	TextInput, 
	StyleSheet,
	AsyncStorage,
	KeyboardAvoidingView
} from 'react-native';

const Tab = createBottomTabNavigator();

import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import Logo from '../loadLogos/secondLogo.js';

import {styles} from '../stylesheet/stylesheet1.js'

export default class login extends Component {
    constructor(props) {
        super(props);
        this.state = {
            id: -1,
            token: '',
            email: '',
            password: '',
        }//this.state ends here
    }//constructor() ends here

    setEmail = (email) => { 
		this.state.email = email 
	}
    setPassword = (password) => { 
		this.state.password = password 
	}
    setID = () => { 
		AsyncStorage.setItem('id', this.state.id) 
	}
    setToken = () => { 
		AsyncStorage.setItem('Token',this.state.token) 
	}

    userLogin = () => {
		//setting constant for navigation props
        const { navigate } = this.props.navigation;
		//setting url
        const serverURL = 'http://10.0.2.2:3333/api/v0.0.5/login';
		fetch(serverURL, {
			method: 'POST',
			headers: {
				Accept: 'application/json',
				'Content-Type': 'application/json'
			},
			body: JSON.stringify({
				email: this.state.email,
				password: this.state.password,
			})
		}) .then(response => response.json())
		.then((returnJSON) => {
			console.log("returnJSON: "+returnJSON)
			this.setState({id: returnJSON.id})
			this.setState({token: returnJSON.token})
			const id = this.state.id
			const dispToken = this.state.token
			console.log("Login Screen User ID: " + id)
			console.log("Login Screen Token: " + dispToken)
			this.setToken()
			this.setID();	
			navigate("userProfile"); //navigates to specified page 
		});
    }//userLogin ends here

    render() {
        return (
            <KeyboardAvoidingView style={styles.mainContainer}>
				<Logo/>
				<Text style={styles.centerText}>JS Filename: login.js</Text>
				<Text/>
				<Text style={styles.mainText}>Please enter valid credentials in the fields below to login.</Text>
				<Text/>
				<Text style={styles.subHeading}>EMAIL:</Text> 
				<TextInput 
					placeholder="Type your email here" 
					onChangeText={this.setEmail} 
					underlineColorAndroid="transparent"
					style={styles.textInputStyle}
				/>
				<Text style={styles.subHeading}>PASSWORD:</Text> 
				<TextInput 
					placeholder="Type your password here" 
					onChangeText={this.setPassword}
					secureTextEntry={true} //hides password when being typed in
					underlineColorAndroid="transparent"
					style={styles.textInputStyle}
				/>
				<Button 
					title="Login" 
					color="darkgreen"
					onPress={this.userLogin}
				/>
				<Text/>
				<Text style={styles.note}>NOTE: If you can't login, make sure you have an account set up and are using valid credentials.</Text>
            </KeyboardAvoidingView>
        )//return ends here
    }//render() ends here
	
}//class 'login' ends here
