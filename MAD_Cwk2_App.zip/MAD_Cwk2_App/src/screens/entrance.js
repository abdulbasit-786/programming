import React, { Component } from 'react';

import { 
	Text, 
	View,
	Button,
	StyleSheet, 
} from 'react-native';

import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from 'react-navigation-stack';

import MainLogo from '../loadLogos/mainLogo.js';

import {styles} from '../stylesheet/stylesheet1.js'

export default class welcome extends Component {
    render() {
        const { navigate } = this.props.navigation;
        return (
            <View style={styles.mainContainer}>
				<MainLogo/>
				<Text style={styles.centerText}>JS Filename: entrance.js</Text>
				<Text/>
                <Text style={styles.heading}>Welcome MMU Chittrers!</Text>
                <Text/>
				<Text/>
				<Text>If you already have an account, click 'LOGIN' button.</Text>
                <Text/>
				<Button title="Login" color="darkgreen" onPress={() => navigate("login")} />
				<Text/>
				<Text/>
				<Text>If you don't have an account, click 'CREATE ACCOUNT' button.</Text>
                <Text/>
				<Button title="Create Account" color="darkgreen" onPress={() => navigate("createAccount")} />
				</View>
        )//return ends here
    }//render() ends here
	
}//class 'welcome' ends here
