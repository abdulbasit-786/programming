import React, { Component } from 'react';

import { 
	Text, 
	View, 
	Button, 
	FlatList, 
	StyleSheet,
	ActivityIndicator
} from 'react-native';

import Logo from '../loadLogos/secondLogo.js';

import {styles} from '../stylesheet/stylesheet1.js'

import viewChitPhoto from '../actions/viewChitPhoto.js'

export default class chitsFeed extends Component {
    constructor(props){
        super(props);
        this.state={
            isLoading: true,
            chitsData: []
        }
    }//constructor ends here

	getData(){
        return fetch('http://10.0.2.2:3333/api/v0.0.5/chits')
            .then((response) => response.json()).then((responseJson) =>{
                this.setState({
                    isLoading: false, chitsData: responseJson,
                });
            })
            .catch((error) =>{
                console.log(error);
            });
    }//getData() ends here
	
    componentDidMount(){
        this.getData();
    }//componentDidMount() ends here
	
	chitPhoto = () => {
        const { navigate } = this.props.navigation;
        navigate(viewChitPhoto);
    }//chitPhoto() ends here
	
	render(){
        if (this.state.isLoading){
            return (
				<View> 
					<ActivityIndicator/> 
				</View>
			)
        }//IF statement ends here
		
		return (
            <View style={styles.mainContainer}>
				<Logo/>
				<Text style={styles.centerText}>JS Filename: chitsFeed.js</Text>
                <Text style={styles.heading}>Chits Feed Page</Text>
				<Text style={styles.mainText}>Chits Feed is shown below.</Text>
				<Text/>
                <FlatList
                    data={this.state.chitsData}
                    renderItem={({ item }) => (
						<View>
							<Text>CHIT: {item.chit_content}</Text>
							<Text/>
						</View>
                    )}
					keyExtractor={(item) => item.user_id}
                />
                <Button 
					title="Chit Photo" 
					color="darkgreen" 
					onPress={this.chitPhoto} 
				/>
            </View>
        );//return ends here
    }//render() ends here
	
}//class 'chitsFeed' ends here
