import React, { Component } from 'react';

import { 
	Text, 
	View, 
	Button, 
	TextInput,
	StyleSheet,
	ToastAndroid 
} from 'react-native';

import Logo from '../loadLogos/secondLogo.js';

import {styles} from '../stylesheet/stylesheet1.js'

export default class AccountCreation extends Component {
    constructor(props){
        super(props);
        this.state={
            given_name: '',
            family_name: '',
            email: '',
            password: '',
        };
    }//constructor ends here
	
    setFirstName = (given_name) => { 
		this.state.given_name = given_name 
	}
    setLastName = (family_name) => { 
		this.state.family_name = family_name 
	}
    setEmail = (email) => { 
		this.state.email = email 
	}
    setPassword = (password) => { 
		this.state.password = password 
	}

    createAccount = () => {
        return fetch("http://10.0.2.2:3333/api/v0.0.5/user", {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                given_name: this.state.given_name,
                family_name: this.state.family_name,
                email: this.state.email,
                password: this.state.password
            })
        })
        .then((response) => {
            ToastAndroid.show('SUCCESS: Account created.', ToastAndroid.SHORT);
            console.log(response)
        })
        .catch((error) => {
            ToastAndroid.show('ERROR: Failed to create account.', ToastAndroid.SHORT);
            console.log(error);
        });
    }//createAccount ends here
	
    render() {
        return (
            <View style={styles.mainContainer}>
                <Logo/>
				<Text style={styles.centerText}>JS Filename: createAccount.js</Text>
				<Text/>
				<Text style={styles.mainText}>Please fill in the form below to create a new Account.</Text>
                <Text/>
				<Text style={styles.subHeading}>FIRST NAME:</Text> 
                <TextInput 
					placeholder="Enter your first name here" 
					//value = {this.state.given_name}
					onChangeText={(value1) => this.setState({"given_name":value1})}
					//onChangeText={this.setFirstName}
					style={styles.textInputStyle}
				/>
				<Text style={styles.subHeading}>LAST NAME:</Text> 
                <TextInput 
					placeholder="Enter your last name here" 
					//value = {this.state.family_name}
					onChangeText={(value2) => this.setState({"family_name":value2})}
					//onChangeText={this.setLastName} 
					style={styles.textInputStyle}
				/>
				<Text style={styles.subHeading}>EMAIL:</Text> 
                <TextInput 
					placeholder="Enter your email here" 
					//value = {this.state.email}
					onChangeText={(value3) => this.setState({"email":value3})}
					//onChangeText={this.setEmail} 
					style={styles.textInputStyle}
				/>
				<Text style={styles.subHeading}>PASSWORD:</Text> 
                <TextInput 
					placeholder="Enter your password here" 
					//value = {this.state.password}
					onChangeText={(value4) => this.setState({"password":value4})}
					//onChangeText={this.setPassword} 
					secureTextEntry={true} //hides password when being typed
					style={styles.textInputStyle}
				/>
                <Button 
					title="Create Account"
					color="darkgreen"
					onPress={this.createAccount}
				/>
            </View>
        );//render ends here
    }//render() ends here
	
}//class 'AccountCreation' ends here
