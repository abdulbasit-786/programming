import React, { Component } from 'react';

import { 
	Text, 
	View,
	Alert,
	Button, 
	TextInput,
	StyleSheet,
	AsyncStorage,
	ToastAndroid,
	PermissionsAndroid,
	KeyboardAvoidingView
} from 'react-native';

import Geolocation from 'react-native-geolocation-service';

import Logo from '../loadLogos/secondLogo.js';

import {styles} from '../stylesheet/stylesheet1.js';

export default class postChit extends Component {
    constructor(props) {
        super(props);
        this.state = {
			chit_id: -1,
			timestamp: 0,
			chit_content:'',
			location: {
			  longitude: -1,
			  latitude: -1,
			}, locationPermission: false,
			user: {
			  user_id: -1,
			  given_name:'',
			  family_name:'',
			  email:'',
			}
		};//this.state ends here
    }//constructor ends here
	
	setLatitude = (latitude) => { 
		this.state.location.latitude = parseInt(latitude); 
	}
    setLongitude = (longitude) => { 
		this.state.location.longitude = parseInt(longitude); 
	}
    setGivenName = (given_name) => { 
		this.state.user.given_name = given_name; 
	}
    setFamilyName = (family_name) => { 
		this.state.user.family_name = family_name; 
	}
    setEmail = (email) => { 
		this.state.user.email = email; 
	}
	
	locationPermissionRequest = async () => {
        try {
            const granted = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION, {
                title: 'Chit Location Permission',
                message: 'Location access required by app!',
                buttonPositive: 'Accept',
                buttonNegative: 'Decline',
				buttonNeutral: 'Ask Later',
            });
            if (granted === PermissionsAndroid.RESULTS.GRANTED) {
				ToastAndroid.show('Location access granted.', ToastAndroid.SHORT);
                console.log('Location access granted.');
                return true;
            } else {
				ToastAndroid.show('Location access declined.', ToastAndroid.SHORT);
                console.log('Location access declined.');
                return false;
            }
        } catch (error) {
			ToastAndroid.show('ERROR: Chit not posted.', ToastAndroid.SHORT);
            console.warn(error);
        }
    }//locationPermissionRequest ends here

	getCoords = () => {
        if (!this.state.locationPermission) {
            this.state.locationPermission = this.locationPermissionRequest();
        } Geolocation.getCurrentPosition(
            (position) => {
                const location = JSON.stringify(position);
                const locationJSON = JSON.parse(location);
                this.setLatitude(locationJSON.coords.latitude);
                this.setLongitude(locationJSON.coords.longitude);
                const latitude = this.state.location.latitude;
				const longitude = this.state.location.longitude;
                const stringLatitude = latitude.toString();
                const stringLongitude = longitude.toString();
				console.log(location);
                console.log("Latitude: " + stringLatitude)
                console.log("Longitude: " + stringLongitude)
            }, 
			(error) => { 
				ToastAndroid.show(error.message, ToastAndroid.SHORT);
				console.log(error.message)
			}, 
			{ 
				enableHighAccuracy: true, 
				timeout: 20000, 
				maximumAge: 1000 
			}
		);
    };//getCoords ends here
	
	componentDidMount = () => {
        this.getCoords();
    }//componentDidMount ends here

    getID = async () => {
        try {
            const id = await AsyncStorage.getItem('id');
            console.log("ID Obtained: " + id)
            if (id !== null) {
                this.state.user.user_id = parseInt(id);
                return (id)
            }
        } catch (error) {
            console.log(error)
        }
    };//getID ends here

    getToken = async () => {
        try {
            const token = await AsyncStorage.getItem('Token');
            if (token !== null) {
                console.log("Token Obtained:" + token)
                return (token)
            }
        } catch (error) {
            console.log(error)
        }
    };//getToken ends here
	
    waitingTimer = async () => {
		var id = await this.getID();
        var token = await this.getToken();
        this.setState({ token: token });
        this.addChitToFeed();
    }//waitingTimer ends here
	
	addChitToFeed() {
		const token = this.state.token
		const { navigate } = this.props.navigation;
		const serverURL = "http://10.0.2.2:3333/api/v0.0.5/chits/"
        return fetch( serverURL, {
			method: 'POST',
			headers: {
				Accept: 'application/json',
				'Content-Type': 'application/json',
				'X-Authorization': "" + token
			},
			body: JSON.stringify({
				chit_id: this.state.chit_id,
				timestamp: this.state.timestamp,
				chit_content: this.state.chit_content,
				location: {
					latitude: this.state.location.latitude,
					longitude: this.state.location.longitude,
				}, user: {
					user_id: this.state.user.user_id,
					given_name: this.state.given_name,
					family_name: this.state.family_name,
					email: this.state.email
				}
			})
		}).then((response) => {
			Alert.alert("Chit Posted Successfully!");
		}).catch((error) => {
			console.error(error);
		});
	}//addChitToFeed() ends here

	render() {
		const { navigate } = this.props.navigation;
        return (
            <KeyboardAvoidingView style={styles.mainContainer}>
				<Logo/>
				<Text style={styles.centerText}>JS Filename: postChit.js</Text>
                <Text style={styles.heading}>Post Chit Page</Text>
				<Text style={styles.mainText}>Fill in the form below to post a Chit.</Text>
				<Text/>
                <TextInput 
					placeholder="Enter Chit Content Here" 
					onChangeText={(chit_content) => this.setState({ chit_content: chit_content })} 
					underlineColorAndroid="transparent"
					style={styles.textInputStyle}
				/>
                <TextInput 
					placeholder="Enter First Name Here" 
					onChangeText={(given_name) => this.setGivenName(given_name)} 
					underlineColorAndroid="transparent"
					style={styles.textInputStyle}
				/>
                <TextInput 
					placeholder="Enter Surname Here" 
					onChangeText={(family_name) => this.setFamilyName(family_name)} 
					underlineColorAndroid="transparent"
					style={styles.textInputStyle}
				/>
                <TextInput 
					placeholder="Enter Email Here" 
					onChangeText={(email) => this.setEmail(email)} 
					underlineColorAndroid="transparent"
					style={styles.textInputStyle}
				/>
				<Button 
					title="Add / Post Chit" 
					color="darkgreen"
					onPress={() => this.waitingTimer()} 
				/>
                <Text/>
                <Button 
					title="Upload Chit Photo" 
					color="darkgreen" 
					onPress={() => navigate("uploadChitPhoto")} 
				/>
				<Text/>
                <Button 
					title="View Chit Photo" 
					color="darkgreen" 
					onPress={() => navigate("viewChitPhoto")} 
				/>
			</KeyboardAvoidingView>
		)//return ends here
	}//render() ends here
	
}//class 'postChit' ends here
