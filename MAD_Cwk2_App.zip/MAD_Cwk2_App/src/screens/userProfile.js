import React, { Component } from 'react';

import { 
	Text, 
	View, 
	Alert, 
	Button, 
	TextInput,
	ScrollView,	
	StyleSheet,
	ToastAndroid, 
	AsyncStorage,
	SafeAreaView,
	ActivityIndicator
} from 'react-native';

import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import Logo from '../loadLogos/secondLogo.js';

import {styles} from '../stylesheet/stylesheet1.js'

export default class userProfile extends Component {
	constructor(props) {
        super(props);
        this.state = { token: '' }
    }//constructor ends here
	
	getToken = async () => {
        try {
            const token = await AsyncStorage.getItem('Token');
            if (token !== null) {
                return (token)
            }
        } catch (error) { 
			console.log(error) 
		}
    };//getToken ends here
	
	setToken = async (token) => {
		try {
			await AsyncStorage.setItem('Token', token);
		} catch (error) {
			console.log(error)
		}
	};//setToken ends here
	
	showTokenID = async () => {
		const id = await AsyncStorage.getItem('id');
		const token = await AsyncStorage.getItem('Token');
		const idString = id.toString();
		console.log(idString)
		console.log(token)
	}//showTokenID ends here
	
	componentDidMount = () => {
		this.setToken();
    }//componentDidMount ends here
	
	//returns user to 'Entrance/Home' page by running logout.js page
	logoutUser = () => {
        const { navigate } = this.props.navigation;
		navigate("logout") 
    }//logoutUser ends here
	
	//takes user to updateAccountDetails.js page
	updateAccountDetails = () => {
        const token = this.getToken();
        this.setState({ token: token })
        const { navigate } = this.props.navigation;
        navigate("updateAccountDetails"); 
    }//updateAccountDetails ends here
	
	//takes user to enterIDToSeeUserFollowers.js page
	followers = () => {
        const token = this.getToken();
        this.setState({ token: token })
        const { navigate } = this.props.navigation;
        navigate("enterIDToSeeUserFollowers"); 
    }//followers ends here
	
	//takes user to selectUserToSeeAccountsFollowedBy.js page
	followedUsers = () => {
        const token = this.getToken();
        this.setState({ token: token })
        const { navigate } = this.props.navigation;
        navigate("selectUserToSeeAccountsFollowedBy"); 
    }//followedUsers ends here
	
	//takes user to displayUserPhoto.js page
	displayUserPhoto = () => {
		const token = this.getToken();
        this.setState({ token: token })
        const { navigate } = this.props.navigation;
        navigate("displayUserPhoto"); 
	}//displayUserPhoto ends here
	
	//takes user to followUser.js page
	followUser = () => {
		const token = this.getToken();
        this.setState({ token: token })
        const { navigate } = this.props.navigation;
        navigate("followUser"); 
	}//followUser ends here
	
	//takes user to unfollowUser.js page
	unfollowUser = () => {
		const token = this.getToken();
        this.setState({ token: token })
        const { navigate } = this.props.navigation;
        navigate("unfollowUser"); 
	}//unfollowUser ends here
	
	//takes user to specifySingleUserToView.js page
	specifySingleUserToView = () => {
		const token = this.getToken();
        this.setState({ token: token })
        const { navigate } = this.props.navigation;
        navigate("specifySingleUserToView"); 
	}//specifySingleUserToView ends here
	
	//takes user to specifyUserToSearchFor.js page
	specifyUserToSearchFor = () => {
		const token = this.getToken();
        this.setState({ token: token })
        const { navigate } = this.props.navigation;
        navigate("specifyUserToSearchFor"); 
	}//specifyUserToSearchFor ends here
			
	//takes user to enterIDToSeeUserFollowers.js page
	enterIDToSeeUserFollowers = () => {
		const token = this.getToken();
        this.setState({ token: token })
        const { navigate } = this.props.navigation;
        navigate("enterIDToSeeUserFollowers"); 
	}//enterIDToSeeUserFollowers ends here
		
	selectUserToSeeAccountsFollowedBy = () => {
		const token = this.getToken();
        this.setState({ token: token })
        const { navigate } = this.props.navigation;
        navigate("selectUserToSeeAccountsFollowedBy"); //takes user to specified page
	}//selectUserToSeeAccountsFollowedBy ends here

	render() {
		return(
		<SafeAreaView style={styles.mainContainer}>
			<ScrollView style={styles.scrollView}>
				<Logo/>
				<Text style={styles.centerText}>JS Filename: userProfile.js</Text>
				<Text/>
				<Text style={styles.heading}>User Profile / Account</Text>
				<Text/>
				<Text style={styles.mainText}>Interact with the buttons below to users followed by this account, view users following this account, update details about this account, or to logout from this account.</Text>
				<Text/>
				<Text>Use this button to logout from this account.</Text>
				<Button title="Logout" color="maroon" onPress={this.logoutUser} />
				<Text/>
				
				<Text style={styles.mainText}>MY ACCOUNT OPTIONS:</Text>
				<Text/>
				<Text>Use this button to update details of this account.</Text>
				<Button title="Update Details" color="darkgreen" onPress={this.updateAccountDetails} />
				<Text/>
				<Text>Use this button to view users following this account.</Text>
				<Button title="My Followers" color="darkgreen" onPress={this.followers} />
				<Text/>
				<Text>Use this button to view users followed by this account.</Text>
				<Button title="Followed Users" color="darkgreen" onPress={this.followedUsers} />
				<Text/>
				<Text>Use this button to view user profile picture.</Text>
				<Button title="View Profile Picture" color="darkgreen" onPress={this.displayUserPhoto} />
				<Text/>
				
				<Text>Use this button to follow a user.</Text>
				<Button title="Follow A User" color="darkgreen" onPress={this.followUser} />
				<Text/>
				<Text>Use this button to unfollow a user.</Text>
				<Button title="Unfollow A User" color="darkgreen" onPress={this.unfollowUser} />
				<Text/>
				
				<Text style={styles.mainText}>OTHER USERS:</Text>
				<Text/>
				<Text>Use this button to search a user account.</Text>
				<Button title="Search A User Account" color="darkblue" onPress={this.specifySingleUserToView} />
				<Text/>
				<Text>Use this button to view details of a user.</Text>
				<Button title="View User Account Details" color="darkblue" onPress={this.specifyUserToSearchFor} />
				<Text/>
				<Text>Use this button to search followers of a user.</Text>
				<Button title="Search Followers Of A User" color="darkblue" onPress={this.enterIDToSeeUserFollowers} />
				<Text/>
				<Text>Use this button to search accounts followed by a user.</Text>
				<Button title="Search Accounts Followed By A User" color="darkblue" onPress={this.selectUserToSeeAccountsFollowedBy} />
			</ScrollView>
		</SafeAreaView>
		)//return ends here
	}//render() ends here
	
}//class 'userProfile' ends here
