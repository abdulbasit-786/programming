import React, { Component } from 'react';

import { 
	Text, 
	View, 
	Button, 
	TextInput, 
	ToastAndroid, 
	AsyncStorage
} from 'react-native';

import Logo from '../loadLogos/secondLogo.js';

import {styles} from '../stylesheet/stylesheet1.js'

export default class updateAccountDetails extends Component {
    constructor(props) {
        super(props);
        this.state = {
            given_name: '',
            family_name: '',
            email: '',
            password: '',
			//user_id: -1,
			//token: ''
        };
    }//constructor ends here
	
	/*setGivenName = (givenNameEntered) => {
        this.state.given_name = givenNameEntered
    }
    setFamilyName = (familyNameEntered) => {
        this.state.family_name = familyNameEntered
    }
    setEmail = (emailEntered) => {
        this.state.email = emailEntered
    }
    setPassword = (passwordEntered) => {
        this.state.password = passwordEntered
    }*/

	getToken = async () => {
        try {
            const token = await AsyncStorage.getItem('Token');
            if (token !== null) {
                console.log("Token Obtained:" + token)
				this.state.token = token;
                return (token)
            }
        } catch (error) {
            console.log(error)
        }
    };//getToken ends here

	getID = async () => {
        try {
            const id = await AsyncStorage.getItem('id');
            console.log("ID Obtained: " + id)
            if (id !== null) {
				this.state.user_id = id;
                return (id)
            }
        } catch (error) {
			ToastAndroid.show("Error Updating Details!", ToastAndroid.SHORT);
            console.log(error)
        }
    };//getID ends here
	
	componentDidMount = async () => {
		await this.getID();
		await this.getToken();
	}
	
	// waitingTimer = async () => {
        // var id = await this.getID();
        // var token = await this.getToken();
        // this.setState({token: token})
        // this.updateAccountDetails();
    // }//waitingTimer ends here

    updateAccountDetails = async () => {
		const id = this.state.user_id;
		const idInt = parseInt(id);
		//const token = await this.getToken();
        //const tokenString = token.toString();
		//const id = await this.getID();
		const token = this.state.token;
        const tokenString = token.toString();
        const serverURL = "http://10.0.2.2:3333/api/v0.0.5/user/"+idInt
        fetch (serverURL, {
			method: 'PATCH',
			headers: {
				'Content-Type': 'application/json',
				'X-Authorization': "" + tokenString
			},
			body: JSON.stringify({
				given_name: this.state.given_name,
				family_name: this.state.family_name,
				email: this.state.email,
				password: this.state.password,
			})
		}) .then((response) => {
			ToastAndroid.show('SUCCESS: Account updated.', ToastAndroid.SHORT);
			console.log(response)
		}) .catch((error) => {
			ToastAndroid.show('ERROR: Failed to update account.', ToastAndroid.SHORT);
			console.log(error);
		});
    }//updateAccountDetails() ends here
	
	updateUserPhoto = () => {
        const token = this.getToken();
        this.setState({ token: token })
        const { navigate } = this.props.navigation;
        navigate("updateUserPhoto");
    }//updateUserPhoto ends here
	
    render() {
        return (
			<View style={styles.mainContainer}>
				<Logo/>
				<Text style={styles.centerText}>JS Filename: updateAccountDetails.js</Text>
                <Text style={styles.heading}>Update Account Details</Text>
				<Text style={styles.mainText}>Fill in the form below with details to update the account with.</Text>
				<Text/>
                <TextInput 
					placeholder="Enter First Name Here" 
					onChangeText={(given_name) => this.setState({ given_name: given_name })} 
					underlineColorAndroid="transparent"
					style={styles.textInputStyle}
				/>
                <TextInput 
					placeholder="Enter Surname Here" 
					onChangeText={(family_name) => this.setState({family_name: family_name})}
					underlineColorAndroid="transparent"
					style={styles.textInputStyle}
				/>
                <TextInput 
					placeholder="Enter Email Here" 
					onChangeText={(email) => this.setState({ email: email })} 
					underlineColorAndroid="transparent"
					style={styles.textInputStyle}
				/>
                <TextInput 
					placeholder="Enter Password Here" 
					onChangeText={(password) => this.setState({ password: password })} 
					secureTextEntry={true} //hides password when being typed in
					underlineColorAndroid="transparent"
					style={styles.textInputStyle}
				/>
                <Button 
					title="Update Profile Picture" 
					color="darkgreen" 
					onPress={this.updateUserPhoto} 
				/>
                <Text/>
                <Button 
					title="Update Account" 
					color="darkgreen" 
					onPress={this.updateAccountDetails} 
				/>
            </View>
        );//return ends here
    }//render() ends here
	
}//class 'updateAccountDetails' ends here
