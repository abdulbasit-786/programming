import React, { Component } from 'react';

import {
	Text,
	View,
	Image,
	StyleSheet
} from 'react-native';

export default class mainLogo extends Component {
	render(){
		return(
			<View style={styles.mainContainer}>
				<Image 
					source={require('../images/main_mmu_logo.png')}
				/>
  			</View>
		)
	}//render() ends here
}//class 'mainLogo' ends here

const styles = StyleSheet.create({
	mainContainer: {
		alignItems: 'center',
	},//mainContainer ends here
});//StyleSheet ends here
