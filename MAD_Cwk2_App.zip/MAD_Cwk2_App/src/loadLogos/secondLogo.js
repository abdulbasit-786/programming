import React, { Component } from 'react';

import {
	Text,
	View,
	Image,
	StyleSheet
} from 'react-native';

export default class secondLogo extends Component {
	render(){
		return(
			<View style={styles.mainContainer}>
				<Image 
					source={require('../images/mmu_logo_2.png')}
				/>
  			</View>
		)
	}//render() ends here
}//class 'secondLogo' ends here

const styles = StyleSheet.create({
	mainContainer: {
		alignItems: 'center',
	},//mainContainer ends here
});//StyleSheet ends here
