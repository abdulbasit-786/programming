import { StyleSheet, } from 'react-native';

export const styles = StyleSheet.create({ 
	mainContainer :{
		flex:1,
		margin: 20,
		justifyContent: 'center',
	},//mainContainer ends here
	heading: {
        color: '#D50000',
        fontWeight: 'bold',
        fontSize: 30,
        textAlign: 'center',
    },//heading ends here
	mainText: {
		fontFamily: 'Arial',
		fontStyle: 'italic',
        fontWeight: 'bold',
        fontSize: 16,
        textAlign: 'left',
    },//mainText ends here
	subHeading: {
        fontWeight: 'bold',
        fontSize: 16,
        textAlign: 'left',
    },//subHeading ends here
	centerText: {
		textAlign: 'center',
	},//centerText ends here
	note: {
		fontStyle: 'italic',
		color: '#D50000',
        fontWeight: 'bold',
        fontSize: 16,
        textAlign: 'left',
    },//note ends here
	textInputStyle: {
		textAlign: 'center',
		marginBottom: 14,
		height: 40,
		borderWidth: 2,
		// Set border Hex Color Code Here.
		borderColor: '#D50000',
		// Set border Radius.
		borderRadius: 6 ,
	},//textInputStyle ends here
	
	//>>>>>>>>SCROLLVIEW STYLE<<<<<<<<<<
	//==================================
	scrollView: {
		backgroundColor: 'transparent',
		marginHorizontal: 0,
	},//scrollView ends here
	
	//>>>>>>>>CAMERA STYLE<<<<<<<<<<
	//==============================
	camContainer: { 
		flex: 1, 
		flexDirection: 'column',
	},//camContainer ends here
	camContainer2: {
		flex: 0, 
		flexDirection: 'row', 
		justifyContent: 'center',
	},//camContainer2 ends here
    photoPreview: { 
		flex: 1, 
		alignItems: 'center', 
		justifyContent: 'flex-end', 
	},//photoPreview ends here
    photoCaptureSettings: { 
		flex: 0, 
		margin: 20, 
		padding: 15, 
		borderRadius: 5, 
		alignSelf: 'center', 
		paddingHorizontal: 20, 
	},//capture ends here
	
	//>>>>>>>>IMAGE STYLE<<<<<<<<<<
	//=============================
	imageStyle: { 
		width: 110, 
		height: 110,
	},//imageStyle ends here
	
});//Stylesheet ends here